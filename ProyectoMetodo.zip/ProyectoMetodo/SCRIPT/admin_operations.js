document.addEventListener('DOMContentLoaded', () => {
    const tableBody = document.querySelector('table tbody');
    const currentPage = window.location.pathname.split('/').pop(); // Obtén el nombre del archivo actual

    // Selecciona el archivo PHP correspondiente
    const endpoint = currentPage === "accept_request.html" 
        ? 'PHP/pending_request.php?estado=aceptada' 
        : 'PHP/pending_request.php?estado=pendiente';

    // Obtén los datos de la base de datos
    fetch(endpoint)
        .then(response => response.json())
        .then(data => {
            data.forEach(row => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td data-label="ID">${row.identificador}</td>
                    <td data-label="Nombre completo">${row.nombre_completo}</td>
                    <td data-label="Carrera/Correo">${row.carrera_departamento}</td>
                    <td data-label="Motivo de uso">${row.motivo_uso}</td>
                    <td data-label="Fecha y horario">${row.fecha} ${row.hora_inicio} - ${row.hora_fin}</td>
                    <td data-label="Tipo de equipo">${row.tipo_equipo}</td>
                    <td data-label="Tipo de solicitante">${row.tipo_solicitante}</td>
                    <td data-label="Estado">${row.estado}</td>
                `;

                // Agregar funcionalidad de doble clic solo si el estado es "pendiente"
                if (row.estado === "pendiente") {
                    tr.addEventListener('dblclick', () => {
                        const solicitudId = row.identificador;
                        const tipoSolicitante = row.tipo_solicitante.toLowerCase();
                        let url = ''; // Declarar fuera del bloque para evitar errores
                        if (tipoSolicitante === "estudiante") {
                            url = `pending_student.html?matricula=${solicitudId}`;
                        } else if (tipoSolicitante === "profesor") {
                            url = `pending_teacher.html?teacherId=${solicitudId}`;
                        } else {
                            console.error('Tipo de solicitante desconocido:', tipoSolicitante);
                            return; // Salir si no hay URL válida
                        }
                        window.location.href = url;
                    });
                }

                tableBody.appendChild(tr);
            });
        })
        .catch(error => console.error('Error al cargar los datos:', error));
});
