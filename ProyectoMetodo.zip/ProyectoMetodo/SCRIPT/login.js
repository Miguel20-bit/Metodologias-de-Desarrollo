
history.pushState(null, "", location.href);
    window.onpopstate = function() {
    history.pushState(null, "", location.href);
};

document.getElementById("userRole").addEventListener("change", function () {
    const adminFields = document.getElementById("adminFields");
    const adminCreate = document.getElementById("adminCreate");
    if (this.value === "admin") {
        adminFields.style.display = "block"; // Mostrar campos para administrador
        adminCreate.style.display = "block"; // Mostrar botón para crear administrador
    } else {
        adminFields.style.display = "none";  // Ocultar campos para otros roles
        adminCreate.style.display = "none";  // Ocultar botón para otros roles
    }
});

function createAdmin() {
    const modal = document.getElementById("adminModal");
    modal.style.display = "flex"; // Mostrar el modal
}

function closeAdminModal() {
    const modal = document.getElementById("adminModal");
    modal.style.display = "none"; // Ocultar el modal
}

function submitAdmin() {
    const username = document.getElementById("newAdminUsername").value.trim();
    const password = document.getElementById("newAdminPassword").value.trim();

    if (username && password) {
        fetch("PHP/create_admin.php", {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: `username=${username}&password=${password}`
        })
        .then(response => response.text())
        .then(result => {
            if (result === "success") {
                showCustomAlert("Administrador creado exitosamente.");
                closeAdminModal();
            } else {
                showCustomAlert("Error al crear el administrador. Intente con otro nombre de usuario.");
            }
        })
        .catch(error => showCustomAlert("Error al conectar con el servidor."));
    } else {
        showCustomAlert("Por favor, complete todos los campos.");
    }
}

// Reemplazar alertas tradicionales por las personalizadas
document.getElementById("loginForm").addEventListener("submit", function (event) {
    event.preventDefault(); // Evita el envío real del formulario

    const userRole = document.getElementById("userRole").value;

    if (userRole === "student") {
        window.location.href = "home_student.html";
    } else if (userRole === "professor") {
        window.location.href = "home_teacher.html";
    } else if (userRole === "admin") {
        const username = document.getElementById("username").value;
        const password = document.getElementById("password").value;

        // Validar usuario y contraseña del administrador usando fetch
        fetch("PHP/login.php", {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: `username=${username}&password=${password}&userRole=admin`
        })
        .then(response => response.text())
        .then(result => {
            if (result === "success") {
                window.location.href = "home_admin.html";
            } else {
                showCustomAlert("Usuario o contraseña incorrectos.");
            }
        })
        .catch(error => showCustomAlert("Error al conectar con el servidor."));
    } else {
        showCustomAlert("Por favor, seleccione un rol válido.");
    }
});

function showCustomAlert(message) {
    const alertBox = document.getElementById("customAlert");
    const alertMessage = document.getElementById("customAlertMessage");
    const overlay = document.getElementById("alertOverlay");

    alertMessage.textContent = message;
    overlay.style.display = "block"; // Mostrar fondo oscuro
    alertBox.style.display = "block"; // Mostrar alerta
}

function closeCustomAlert() {
    const alertBox = document.getElementById("customAlert");
    const overlay = document.getElementById("alertOverlay");

    alertBox.style.display = "none";
    overlay.style.display = "none"; // Ocultar fondo oscuro
}
