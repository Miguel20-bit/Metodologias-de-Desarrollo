document.addEventListener('DOMContentLoaded', () => {
    const tableBody = document.querySelector('table tbody');

    // Llamada al endpoint PHP
    fetch('PHP/fetch_history.php')
        .then(response => response.json())
        .then(data => {
            if (data.length === 0) {
                const noDataRow = document.createElement('tr');
                noDataRow.innerHTML = `<td colspan="9" style="text-align: center;">No hay datos disponibles en el historial</td>`;
                tableBody.appendChild(noDataRow);
                return;
            }

            // Iterar sobre los datos y crear filas dinámicas
            data.forEach(row => {
                const tr = document.createElement('tr');

                tr.innerHTML = `
                    <td data-label="ID">${row.id}</td>
                    <td data-label="Fecha de Préstamo">${row.fecha_prestamo}</td>
                    <td data-label="Tipo de Equipo">${row.tipo_equipo}</td>
                    <td data-label="Equipo">${row.equipo}</td>
                    <td data-label="Identificador de Usuario">${row.identificador_usuario}</td>
                    <td data-label="Tipo de Usuario">${row.tipo_usuario}</td>
                    <td data-label="Estado de Devolución">${row.estado_devolucion}</td>
                    <td data-label="Fecha de Devolución">${row.fecha_devolucion || 'N/A'}</td>
                    <td data-label="Hora de Devolución">${row.hora_devolucion || 'N/A'}</td>
                `;

                tableBody.appendChild(tr);
            });
        })
        .catch(error => console.error('Error al cargar el historial:', error));
});
