// Guardar la solicitud en la base de datos
function handleCreateSubmit() {
    if (!validateReservationForm()) {
        return;
    }

    const formData = new FormData(document.querySelector("#reservationForm"));

    fetch("PHP/create.php", {
        method: "POST",
        body: formData
    })
        .then(response => response.json())
        .then(data => {
            if (data.status === "success") {
                showAlert("Solicitud creada exitosamente.", true);
                setTimeout(() => {
                    window.location.href = "home_teacher.html";
                }, 2000); // Redirigir después de 2 segundos
            } else {
                showAlert("Error al crear la solicitud: " + data.message, false);
            }
        })
        .catch(error => {
            console.error("Error:", error);
            showAlert("Ocurrió un error inesperado.", false);
        });
}

document.addEventListener("DOMContentLoaded", function () {
    const urlParams = new URLSearchParams(window.location.search);
    const teacherId = urlParams.get("teacherId");

    // Mostrar la matrícula en el elemento correspondiente
    document.getElementById("teacherIdDisplay").textContent = teacherId;

    if (teacherId) {

        fetch(`PHP/read.php?teacherId=${teacherId}`)
            .then(response => response.json())
            .then(data => {
                if (data) {
                    // Asignar valores del servidor a los campos del formulario
                    document.getElementById("firstName").value = data.nombre;
                    document.getElementById("date").value = data.fecha;
                    document.getElementById("lastName").value = data.apellidos;
                    document.getElementById("startTime").value = data.hora_inicio;
                    document.getElementById("teacherId").value = data.numero_empleado;
                    document.getElementById("endTime").value = data.hora_fin;
                    document.getElementById("email").value = data.correo;
                    document.getElementById("equipmentType").value = data.tipo_equipo;
                    document.getElementById("phoneNumber").value = data.telefono;
                    document.getElementById("useReason").value = data.motivo_uso;
                    document.getElementById("useLocation").value = data.ubicacion_uso;

                    // Actualizar opciones de equipos y seleccionar el equipo cargado
                    updateEquipmentOptions();
                    document.getElementById("equipment").value = data.equipo_disponible;

                    // Actualizar la imagen del equipo
                    updateEquipmentImage();

                } else {
                    showAlert("No se encontraron datos para el número de empleado proporcionado.", false);
                }
            })
            .catch(error => console.error("Error:", error));
    }
});

// Función para manejar la modificación de la reservación
function handleModifySubmit() {

    const teacherId = document.getElementById("teacherIdDisplay").textContent;
    const formData = new FormData(document.querySelector("form"));
    formData.append("teacherId", teacherId);

    fetch("PHP/update.php", {
        method: "POST",
        body: formData
    })
        .then(response => response.json())
        .then(data => {
            showAlert(data.message, data.status === "success");
            if (data.status === "success") {
                setTimeout(() => {
                    window.location.href = "home_teacher.html";
                }, 2000); // Regresar después de 2 segundos
            }
        })
        .catch(error => {
            console.error("Error:", error);
            showAlert("Hubo un problema al modificar la solicitud.", false);
        });
}

function handleDelete() {
    
    const overlay = document.getElementById("overlay");
    const deleteConfirmation = document.createElement("div");
    deleteConfirmation.className = "delete-confirmation";
    deleteConfirmation.innerHTML = `
        <h3>Confirmar eliminación</h3>
        <p>¿Estás seguro de que deseas eliminar esta solicitud?</p>
        <button class="confirm-button">Eliminar</button>
        <button class="cancel-button">Cancelar</button>
    `;

    document.body.appendChild(deleteConfirmation);
    overlay.style.display = "block";
    deleteConfirmation.style.display = "block";

    // Botón de confirmación
    deleteConfirmation.querySelector(".confirm-button").onclick = () => {
        const teacherId = document.getElementById("teacherIdDisplay").textContent;

        fetch("PHP/delete.php", {
            method: "DELETE",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ teacherId }),
        })
            .then(response => response.json())
            .then(data => {
                if (data.status === "success") {
                    showAlert("La solicitud ha sido eliminada con éxito.", true);
                    setTimeout(() => window.location.href = "home_teacher.html", 2000);
                } else {
                    showAlert("Error al eliminar la solicitud.", false);
                }
            })
            .catch(error => {
                console.error("Error:", error);
                showAlert("Hubo un problema al eliminar la solicitud.", false);
            })
            .finally(() => {
                closeConfirmation(deleteConfirmation, overlay);
            });
    };

    // Botón de cancelar
    deleteConfirmation.querySelector(".cancel-button").onclick = () => {
        closeConfirmation(deleteConfirmation, overlay);
    };
}

function handleDecline() {
    const teacherId = document.getElementById("teacherIdDisplay").textContent;

    if (!teacherId) {
        showAlert("No se encontró el numero de empleado.", false);
        return;
    }

    // Confirmación de rechazo
    Swal.fire({
        title: '¿Estás seguro?',
        text: "Esta acción rechazará la solicitud.",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Sí, rechazar',
        cancelButtonText: 'Cancelar',
    }).then((result) => {
        if (result.isConfirmed) {
            fetch("PHP/update_status.php", {
                method: "POST",
                headers: { "Content-Type": "application/x-www-form-urlencoded" },
                body: new URLSearchParams({ teacherId, estado: 'rechazada' }),
            })
                .then(response => response.json())
                .then(data => {
                    if (data.status === "success") {
                        Swal.fire({
                            title: 'Rechazada',
                            text: data.message,
                            icon: 'success',
                        }).then(() => {
                            window.location.href = "pending_request.html";
                        });                        
                    } else {
                        Swal.fire('Error', data.message, 'error');
                    }
                })
                .catch(error => {
                    console.error("Error:", error);
                    Swal.fire('Error', 'Ocurrió un error inesperado.', 'error');
                });
        }
    });
}

function handleAccept() {
    const teacherId = document.getElementById("teacherIdDisplay").textContent;

    if (!teacherId) {
        showAlert("No se encontró el número de empleado.", false);
        return;
    }

    Swal.fire({
        title: '¿Estás seguro?',
        text: "Esta acción aceptará la solicitud y actualizará el inventario.",
        icon: 'info',
        showCancelButton: true,
        confirmButtonText: 'Sí, aceptar',
        cancelButtonText: 'Cancelar',
    }).then((result) => {
        if (result.isConfirmed) {
            fetch("PHP/update_status_teacher.php", {
                method: "POST",
                headers: { "Content-Type": "application/x-www-form-urlencoded" },
                body: new URLSearchParams({ teacherId, estado: 'aceptada' }),
            })
                .then(response => response.json())
                .then(data => {
                    if (data.status === "success") {
                        Swal.fire({
                            title: 'Aceptada',
                            text: data.message,
                            icon: 'success',
                        }).then(() => {
                            window.location.href = "pending_request.html";
                        });
                    } else {
                        Swal.fire('Error', data.message, 'error');
                    }
                })
                .catch(error => {
                    console.error("Error:", error);
                    Swal.fire('Error', 'Ocurrió un error inesperado.', 'error');
                });
        }
    });
}

function closeConfirmation(deleteConfirmation, overlay) {
    deleteConfirmation.remove();
    overlay.style.display = "none";
}

// Cerrar alerta
function closeAlert() {
    const overlay = document.getElementById("overlay");
    const alertDiv = document.getElementById("alert");

    overlay.style.display = "none";
    alertDiv.classList.remove("show");
}

