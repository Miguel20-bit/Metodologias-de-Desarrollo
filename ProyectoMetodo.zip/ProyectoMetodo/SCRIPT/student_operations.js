// Guardar la solicitud en la base de datos
function handleCreateSubmit() {
    if (!validateReservationForm()) {
        return;
    }

    const formData = new FormData(document.querySelector("#reservationForm"));

    fetch("PHP/create.php", {
        method: "POST",
        body: formData
    })
        .then(response => response.json())
        .then(data => {
            if (data.status === "success") {
                showAlert("Solicitud creada exitosamente.", true);
                setTimeout(() => {
                    window.location.href = "home_student.html";
                }, 2000); // Redirigir después de 2 segundos
            } else {
                showAlert("Error al crear la solicitud: " + data.message, false);
            }
        })
        .catch(error => {
            console.error("Error:", error);
            showAlert("Ocurrió un error inesperado.", false);
        });
}

document.addEventListener("DOMContentLoaded", function () {
    const urlParams = new URLSearchParams(window.location.search);
    const matricula = urlParams.get("matricula");

    // Mostrar la matrícula en el elemento correspondiente
    document.getElementById("matriculaDisplay").textContent = matricula;

    if (matricula) {
        fetch(`PHP/read.php?matricula=${matricula}`)
            .then(response => response.json())
            .then(data => {
                if (data) {
                    // Asignar valores del servidor a los campos del formulario
                    document.getElementById("firstName").value = data.nombre;
                    document.getElementById("date").value = data.fecha;
                    document.getElementById("lastName").value = data.apellidos;
                    document.getElementById("startTime").value = data.hora_inicio;
                    document.getElementById("studentId").value = data.matricula;
                    document.getElementById("endTime").value = data.hora_fin;
                    document.getElementById("semester").value = data.semestre;
                    document.getElementById("equipmentType").value = data.tipo_equipo;
                    document.getElementById("career").value = data.carrera;
                    document.getElementById("useReason").value = data.motivo_uso;
                    document.getElementById("useLocation").value = data.ubicacion_uso;

                    // Actualizar opciones de equipos y seleccionar el equipo cargado
                    updateEquipmentOptions();
                    document.getElementById("equipment").value = data.equipo_disponible;

                    // Actualizar la imagen del equipo
                    updateEquipmentImage();

                } else {
                    alert("No se encontraron datos para la matrícula proporcionada.");
                }
            })
            .catch(error => console.error("Error al obtener los datos:", error));
    }
});

// Función para manejar la modificación de la reservación
function handleModifySubmit() {

    const matricula = document.getElementById("matriculaDisplay").textContent;
    const formData = new FormData(document.querySelector("form"));
    formData.append("matricula", matricula);

    fetch("PHP/update.php", {
        method: "POST",
        body: formData
    })
        .then(response => response.json())
        .then(data => {
            showAlert(data.message, data.status === "success");
            if (data.status === "success") {
                setTimeout(() => {
                    window.location.href = "home_student.html";
                }, 2000); // Regresar después de 2 segundos
            }
        })
        .catch(error => {
            console.error("Error:", error);
            showAlert("Hubo un problema al modificar la solicitud.", false);
        });
}

// Función para manejar la eliminación de la reservación
function handleDelete() {

    const overlay = document.getElementById("overlay");
    const deleteConfirmation = document.createElement("div");
    deleteConfirmation.className = "delete-confirmation";
    deleteConfirmation.innerHTML = `
        <h3>Confirmar eliminación</h3>
        <p>¿Estás seguro de que deseas eliminar esta solicitud?</p>
        <button class="confirm-button">Eliminar</button>
        <button class="cancel-button">Cancelar</button>
    `;

    document.body.appendChild(deleteConfirmation);
    overlay.style.display = "block";
    deleteConfirmation.style.display = "block";

    // Botón de confirmación
    deleteConfirmation.querySelector(".confirm-button").onclick = () => {
        const matricula = document.getElementById("matriculaDisplay").textContent;
        fetch("PHP/delete.php", {
            method: "DELETE",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ matricula }),
        })
            .then(response => response.json())
            .then(data => {
                if (data.status === "success") {
                    showAlert("La solicitud ha sido eliminada con éxito.", true);
                    setTimeout(() => window.location.href = "home_student.html", 2000);
                } else {
                    showAlert("Error al eliminar la solicitud.", false, "IMG/error.gif");
                }
            })
            .catch(error => {
                console.error("Error:", error);
                showAlert("Hubo un problema al eliminar la solicitud.", false);
            })
            .finally(() => {
                closeConfirmation(deleteConfirmation, overlay);
            });
    };

    // Botón de cancelar
    deleteConfirmation.querySelector(".cancel-button").onclick = () => {
        closeConfirmation(deleteConfirmation, overlay);
    };
}

function closeConfirmation(deleteConfirmation, overlay) {
    deleteConfirmation.remove();
    overlay.style.display = "none";
}

function handleDecline() {
    const matricula = document.getElementById("matriculaDisplay").textContent;

    if (!matricula) {
        showAlert("No se encontró la matrícula del estudiante.", false);
        return;
    }

    // Confirmación de rechazo
    Swal.fire({
        title: '¿Estás seguro?',
        text: "Esta acción rechazará la solicitud.",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Sí, rechazar',
        cancelButtonText: 'Cancelar',
    }).then((result) => {
        if (result.isConfirmed) {
            fetch("PHP/update_status.php", {
                method: "POST",
                headers: { "Content-Type": "application/x-www-form-urlencoded" },
                body: new URLSearchParams({ matricula, estado: 'rechazada' }),
            })
                .then(response => response.json())
                .then(data => {
                    if (data.status === "success") {
                        Swal.fire({
                            title: 'Rechazada',
                            text: data.message,
                            icon: 'success',
                        }).then(() => {
                            window.location.href = "pending_request.html";
                        });                        
                    } else {
                        Swal.fire('Error', data.message, 'error');
                    }
                })
                .catch(error => {
                    console.error("Error:", error);
                    Swal.fire('Error', 'Ocurrió un error inesperado.', 'error');
                });
        }
    });
}

function handleAccept() {
    const matricula = document.getElementById("matriculaDisplay").textContent;

    if (!matricula) {
        showAlert("No se encontró la matrícula del estudiante.", false);
        return;
    }

    Swal.fire({
        title: '¿Estás seguro?',
        text: "Esta acción aceptará la solicitud y actualizará el inventario.",
        icon: 'info',
        showCancelButton: true,
        confirmButtonText: 'Sí, aceptar',
        cancelButtonText: 'Cancelar',
    }).then((result) => {
        if (result.isConfirmed) {
            fetch("PHP/update_status_student.php", {
                method: "POST",
                headers: { "Content-Type": "application/x-www-form-urlencoded" },
                body: new URLSearchParams({ matricula, estado: 'aceptada' }),
            })
                .then(response => response.json())
                .then(data => {
                    if (data.status === "success") {
                        Swal.fire({
                            title: 'Aceptada',
                            text: data.message,
                            icon: 'success',
                        }).then(() => {
                            window.location.href = "pending_request.html";
                        });                        
                    } else {
                        Swal.fire('Error', data.message, 'error');
                    }
                })
                .catch(error => {
                    console.error("Error:", error);
                    Swal.fire('Error', 'Ocurrió un error inesperado.', 'error');
                });
        }
    });
}

// Configurar límites de fecha al cargar el DOM
document.addEventListener("DOMContentLoaded", setReservationDateLimits);

// Asociar eventos para actualizar imagen de equipo
document.getElementById("equipment").addEventListener("change", updateEquipmentImage);
