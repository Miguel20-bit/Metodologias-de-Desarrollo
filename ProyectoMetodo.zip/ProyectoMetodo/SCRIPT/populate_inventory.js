// Función para obtener los datos del inventario desde el archivo PHP
async function fetchInventory() {
    try {
        // Realizar la solicitud al archivo PHP
        const response = await fetch("PHP/fetch_inventory.php");
        
        // Convertir la respuesta a formato JSON
        const data = await response.json();

        // Verificar si hubo un error
        if (data.error) {
            console.error("Error al obtener datos:", data.error);
            return;
        }

        // Llenar la tabla con los datos obtenidos
        populateTable(data);
    } catch (error) {
        console.error("Error en la solicitud:", error);
    }
}

// Función para llenar la tabla HTML
function populateTable(data) {
    // Obtener el cuerpo de la tabla
    const tbody = document.querySelector("table tbody");

    // Vaciar cualquier contenido previo en el cuerpo de la tabla
    tbody.innerHTML = "";

    // Recorrer los datos y crear filas para cada elemento
    data.forEach((item) => {
        const row = document.createElement("tr");

        // Crear las celdas para cada columna
        const idCell = document.createElement("td");
        idCell.textContent = item.id;

        const tipoCell = document.createElement("td");
        tipoCell.textContent = item.tipo_equipo;

        const equipoCell = document.createElement("td");
        equipoCell.textContent = item.equipo;

        const cantidadCell = document.createElement("td");
        cantidadCell.textContent = item.cantidad;

        // Agregar las celdas a la fila
        row.appendChild(idCell);
        row.appendChild(tipoCell);
        row.appendChild(equipoCell);
        row.appendChild(cantidadCell);

        // Agregar la fila al cuerpo de la tabla
        tbody.appendChild(row);
    });
}

// Llamar a la función al cargar la página
document.addEventListener("DOMContentLoaded", fetchInventory);
