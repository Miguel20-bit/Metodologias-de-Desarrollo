// Prevenir retroceso en el historial del navegador
history.pushState(null, "", location.href);
    window.onpopstate = function () {
    history.pushState(null, "", location.href);
};

// Datos de equipos
const equipmentData = {
    laptop: [
        { name: "Laptop HP", image: "IMG/laptop_hp.png" },
        { name: "Laptop Dell", image: "IMG/laptop_dell.png" }
    ],
    desktop: [
        { name: "Desktop Lenovo", image: "IMG/desktop_lenovo.png" },
        { name: "Desktop Acer", image: "IMG/desktop_acer.png" }
    ],
    cables: [
        { name: "HDMI", image: "IMG/hdmi.png" },
        { name: "VGA", image: "IMG/vga.png" }
    ],
    microfonos: [
        { name: "Microfono Steren", image: "IMG/microfono_steren.png" },
        { name: "Microfono Tripode", image: "IMG/microfono_tripode.png" }
    ],
    bocinas: [
        { name: "Bocinas PC", image: "IMG/bocinas_pc.png" },
        { name: "Bocina Tripode", image: "IMG/bocina_tripode.png" }
    ],
    proyectores: [
        { name: "Proyector Epson", image: "IMG/proyector_epson.png" },
        { name: "Proyector Epson Negro", image: "IMG/proyector_epson_negro.png" }
    ]
};

// Función para actualizar las opciones de equipos basados en el tipo seleccionado
function updateEquipmentOptions() {
    const equipmentType = document.getElementById("equipmentType").value;
    const equipmentSelect = document.getElementById("equipment");

    equipmentSelect.innerHTML = '<option value="" disabled selected>Seleccione una opción</option>';

    if (equipmentData[equipmentType]) {
        equipmentData[equipmentType].forEach(item => {
            const option = document.createElement("option");
            option.value = item.name;
            option.textContent = item.name;
            equipmentSelect.appendChild(option);
        });
    }
}

// Función para mostrar la imagen del equipo seleccionado
function updateEquipmentImage() {
    const equipmentType = document.getElementById("equipmentType").value;
    const selectedEquipment = document.getElementById("equipment").value;
    const equipmentImage = document.querySelector(".image-placeholder img");

    const selectedItem = equipmentData[equipmentType]?.find(item => item.name === selectedEquipment);
    equipmentImage.src = selectedItem ? selectedItem.image : '#';
    equipmentImage.alt = selectedEquipment || "Sin selección";
}

// Función para establecer límites de fecha para las reservaciones
function setReservationDateLimits() {
    const today = new Date();
    const tomorrow = new Date();
    tomorrow.setDate(today.getDate() + 1);

    const dateInput = document.getElementById("date");
    dateInput.min = today.toISOString().split("T")[0];
    dateInput.max = tomorrow.toISOString().split("T")[0];
}

// Función para validar la duración de la reservación
function validateReservationDuration(startTime, endTime) {
    const workStart = new Date(`1970-01-01T07:00:00`);
    const workEnd = new Date(`1970-01-01T21:00:00`);
    
    if (startTime && endTime) {
        const start = new Date(`1970-01-01T${startTime}:00`);
        const end = new Date(`1970-01-01T${endTime}:00`);

        if (start < workStart || end > workEnd) {
            Swal.fire({
                icon: 'warning',
                title: 'Horario no permitido',
                text: 'Las reservas solo pueden realizarse entre las 7:00 AM y las 9:00 PM.',
                confirmButtonColor: '#008000',
            });
            return false;
        }

        const difference = (end - start) / (1000 * 60 * 60);
        if (difference <= 0 || difference > 2) {
            Swal.fire({
                icon: 'warning',
                title: 'Duración excedida o inválida',
                text: 'La reservación debe ser de 2 horas máximo y con un horario válido.',
                confirmButtonColor: '#008000',
            });
            return false;
        }

        return true;
    }
    return false;
}

// Validación del formulario de reservación
function validateReservationForm() {
    const namePattern = /^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]+$/;
    const matriculaPattern = /^zS\d{8}$/;
    const teacherIdPattern = /^zS\d{8}$/; // Define el patrón faltante
    const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    const phonePattern = /^\d{10}$/;

    const firstName = document.getElementById("firstName")?.value;
    const lastName = document.getElementById("lastName")?.value;
    const studentId = document.getElementById("studentId")?.value;
    const teacherId = document.getElementById("teacherId")?.value;
    const email = document.getElementById("email")?.value;
    const phone = document.getElementById("phoneNumber")?.value;
    const startTime = document.getElementById("startTime")?.value;
    const endTime = document.getElementById("endTime")?.value;

    if (!namePattern.test(firstName) || !namePattern.test(lastName)) {
        Swal.fire({
            icon: 'error',
            title: 'Formato incorrecto',
            text: 'El nombre y los apellidos no deben contener números ni símbolos.',
            confirmButtonColor: '#008000',
        });
        return false;
    }

    if (studentId && !matriculaPattern.test(studentId)) {
        Swal.fire({
            icon: 'error',
            title: 'Formato de matrícula inválido',
            text: 'La matrícula debe tener el formato "zS22016112".',
            confirmButtonColor: '#008000',
        });
        return false;
    }

    if (teacherId && !teacherIdPattern.test(teacherId)) {
        Swal.fire({
            icon: 'error',
            title: 'Formato de número de empleado inválido',
            text: 'El número de empleado debe tener el formato "zS22016112".',
            confirmButtonColor: '#008000',
        });
        return false;
    }

    if (teacherId && !emailPattern.test(email)) {
        Swal.fire({
            icon: 'error',
            title: 'Correo inválido',
            text: 'Por favor, ingrese un correo electrónico válido.',
            confirmButtonColor: '#008000',
        });
        return false;
    }

    if (teacherId && !phonePattern.test(phone)) {
        Swal.fire({
            icon: 'error',
            title: 'Teléfono inválido',
            text: 'El número de teléfono debe contener solo 10 dígitos.',
            confirmButtonColor: '#008000',
        });
        return false;
    }

    if (!validateReservationDuration(startTime, endTime)) {
        Swal.fire({
            icon: 'warning',
            title: 'Duración excedida',
            text: 'La reservación no puede exceder las 2 horas.',
            confirmButtonColor: '#008000',
        });
        return false;
    }

    return true;
}

// Función para mostrar alertas genéricas
function showAlert(message, isSuccess) {
    Swal.fire({
        icon: isSuccess ? 'success' : 'error',
        title: isSuccess ? 'Éxito' : 'Error',
        text: message,
        confirmButtonColor: '#008000', // Personalizado
        background: '#f0f0f0',         // Fondo personalizado
        color: '#003366'              // Texto personalizado
    });
}
