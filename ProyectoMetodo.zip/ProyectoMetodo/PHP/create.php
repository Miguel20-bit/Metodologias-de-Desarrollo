<?php

    // Incluir el archivo de conexión a la base de datos
    include 'db.php';

    // Recuperar datos comunes del formulario
    $nombre = $_POST['firstName'];
    $apellidos = $_POST['lastName']; // Los apellidos se manejan como un único campo
    $fecha = $_POST['date'];
    $hora_inicio = $_POST['startTime'];
    $hora_fin = $_POST['endTime'];
    $tipo_equipo = $_POST['equipmentType'];
    $equipo_disponible = $_POST['equipment'];
    $motivo_uso = $_POST['useReason'];
    $ubicacion_uso = $_POST['useLocation'];
    $estado = "pendiente"; // Valor por defecto para el estado

    // Verificar si se trata de un estudiante o un profesor
    if (isset($_POST['studentId'])) {
        // Datos específicos de estudiantes
        $matricula = $_POST['studentId'];
        $semestre = $_POST['semester'];
        $carrera = $_POST['career'];

        // Verificar si la matrícula ya existe
        $stmt_check = $conn->prepare("SELECT COUNT(*) FROM solicitudes_e WHERE matricula = ?");
        $stmt_check->bind_param("s", $matricula);
        $stmt_check->execute();
        $stmt_check->bind_result($count);
        $stmt_check->fetch();
        $stmt_check->close();

        if ($count > 0) {
            // Si la matrícula ya existe, devolver un mensaje de error
            echo json_encode(["status" => "error", "message" => "Ya existe un registro con esta matrícula."]);
            exit();
        }

        // Si no existe, realizar la inserción
        $stmt = $conn->prepare("
            INSERT INTO solicitudes_e (
                nombre, apellidos, semestre, carrera, matricula, motivo_uso, fecha, hora_inicio, hora_fin, tipo_equipo, equipo_disponible, ubicacion_uso, estado
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->bind_param(
            "sssssssssssss",
            $nombre, $apellidos, $semestre, $carrera, $matricula, $motivo_uso, $fecha, $hora_inicio, $hora_fin, $tipo_equipo, $equipo_disponible, $ubicacion_uso, $estado
        );

        if ($stmt->execute()) {
            echo json_encode(["status" => "success", "message" => "Solicitud creada exitosamente."]);
        } else {
            echo json_encode(["status" => "error", "message" => "Error al insertar registro."]);
        }
        $stmt->close();

    } elseif (isset($_POST['teacherId'])) {
        // Datos específicos de profesores
        $numero_empleado = $_POST['teacherId'];
        $correo = $_POST['email'];
        $telefono = $_POST['phoneNumber'];

        // Verificar si el número de empleado ya existe
        $stmt_check = $conn->prepare("SELECT COUNT(*) FROM solicitudes_p WHERE numero_empleado = ?");
        $stmt_check->bind_param("s", $numero_empleado);
        $stmt_check->execute();
        $stmt_check->bind_result($count);
        $stmt_check->fetch();
        $stmt_check->close();

        if ($count > 0) {
            echo json_encode(["status" => "error", "message" => "Ya existe un registro con este número de empleado."]);
            exit();
        }

        // Si no existe, realizar la inserción
        $stmt = $conn->prepare("
            INSERT INTO solicitudes_p (
                nombre, apellidos, correo, telefono, numero_empleado, motivo_uso, fecha, hora_inicio, hora_fin, tipo_equipo, equipo_disponible, ubicacion_uso, estado
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->bind_param(
            "sssssssssssss",
            $nombre, $apellidos, $correo, $telefono, $numero_empleado, $motivo_uso, $fecha, $hora_inicio, $hora_fin, $tipo_equipo, $equipo_disponible, $ubicacion_uso, $estado
        );

        if ($stmt->execute()) {
            echo json_encode(["status" => "success", "message" => "Solicitud creada exitosamente."]);
        } else {
            echo json_encode(["status" => "error", "message" => "Error al insertar registro."]);
        }
        $stmt->close();
    }

    // Cerrar la conexión con la base de datos
    $conn->close();

?>
