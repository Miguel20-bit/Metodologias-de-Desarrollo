<?php
    include 'db.php';

    if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
        // Leer datos JSON del cuerpo de la solicitud
        $input = json_decode(file_get_contents("php://input"), true);

        if (isset($input['matricula'])) {
            // Eliminar solicitud de estudiante
            $matricula = $input['matricula'];
            $sql = "DELETE FROM solicitudes_e WHERE matricula = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $matricula);

            if ($stmt->execute()) {
                echo json_encode(["status" => "success", "message" => "La solicitud de estudiante ha sido eliminada."]);
            } else {
                echo json_encode(["status" => "error", "message" => "Error al eliminar la solicitud de estudiante."]);
            }

            $stmt->close();
        } elseif (isset($input['teacherId'])) {
            // Eliminar solicitud de profesor
            $teacherId = $input['teacherId'];
            $sql = "DELETE FROM solicitudes_p WHERE numero_empleado = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $teacherId);

            if ($stmt->execute()) {
                echo json_encode(["status" => "success", "message" => "La solicitud de profesor ha sido eliminada."]);
            } else {
                echo json_encode(["status" => "error", "message" => "Error al eliminar la solicitud de profesor."]);
            }

            $stmt->close();
        } else {
            // Ningún identificador válido proporcionado
            echo json_encode(["status" => "error", "message" => "No se proporcionó un identificador válido."]);
        }

        $conn->close();
        exit();
    }
?>
