<?php
// Incluir el archivo con la conexión a la base de datos
include 'db.php'; // Asegúrate de que el archivo tenga este nombre y esté en la misma carpeta

// Consulta para obtener los datos de la tabla inventario
$sql = "SELECT id, tipo_equipo, equipo, cantidad FROM inventario";

// Ejecutar la consulta y verificar si hay resultados
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Crear un arreglo para almacenar los datos
    $inventory = [];

    // Recorrer los resultados y agregar al arreglo
    while ($row = $result->fetch_assoc()) {
        $inventory[] = $row;
    }

    // Retornar los datos en formato JSON
    echo json_encode($inventory);
} else {
    // Enviar un arreglo vacío si no hay resultados
    echo json_encode([]);
}

// Cerrar la conexión a la base de datos
$conn->close();
?>
