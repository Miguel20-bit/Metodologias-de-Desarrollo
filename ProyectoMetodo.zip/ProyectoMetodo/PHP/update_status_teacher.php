<?php
    include 'db.php';

    header('Content-Type: application/json');

    // Verificar si se envió una solicitud de modificación
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['teacherId']) && isset($_POST['estado'])) {
        $teacherId = $conn->real_escape_string($_POST['teacherId']);
        $estado = $conn->real_escape_string($_POST['estado']);

        // Consultar los datos de la solicitud del estudiante
        $query = "SELECT * FROM solicitudes_p WHERE numero_empleado = '$teacherId'";
        $result = $conn->query($query);

        if ($result->num_rows > 0) {
            $solicitud = $result->fetch_assoc();

            // Extraer datos de la solicitud
            $tipo_equipo = $solicitud['tipo_equipo'];
            $equipo_disponible = $solicitud['equipo_disponible'];
            $fecha = $solicitud['fecha'];
            $hora_inicio = $solicitud['hora_inicio'];
            $hora_fin = $solicitud['hora_fin'];
            $ubicacion = $solicitud['ubicacion_uso'];

            // Actualizar el estado de la solicitud
            $sql_update = "UPDATE solicitudes_p SET estado = '$estado' WHERE numero_empleado = '$teacherId'";

            if ($conn->query($sql_update) === TRUE) {
                // Actualizar el inventario, restar 1 al equipo seleccionado
                $sql_inventory = "UPDATE inventario SET cantidad = cantidad - 1 WHERE equipo = '$equipo_disponible' AND tipo_equipo = '$tipo_equipo' AND cantidad > 0";
                if ($conn->query($sql_inventory) === TRUE) {
                    // Registrar el préstamo en el historial
                    $sql_history = "INSERT INTO historial_prestamos (fecha_prestamo, tipo_equipo, equipo, identificador_usuario, tipo_usuario, estado_devolucion)
                                    VALUES ('$fecha', '$tipo_equipo', '$equipo_disponible', '$teacherId', 'profesor', 'pendiente')";
                    if ($conn->query($sql_history) === TRUE) {
                        echo json_encode(['status' => 'success', 'message' => 'Solicitud aceptada, inventario actualizado y préstamo registrado.']);
                    } else {
                        echo json_encode(['status' => 'error', 'message' => 'Error al registrar el préstamo en el historial: ' . $conn->error]);
                    }
                } else {
                    echo json_encode(['status' => 'error', 'message' => 'Error al actualizar el inventario: ' . $conn->error]);
                }
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Error al actualizar el estado de la solicitud: ' . $conn->error]);
            }
        } else {
            echo json_encode(['status' => 'error', 'message' => 'No se encontró la solicitud con el numero de empleado proporcionado.']);
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Parámetros incompletos.']);
    }

    $conn->close(); 
?>
