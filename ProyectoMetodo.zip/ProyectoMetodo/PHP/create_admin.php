<?php
    include 'db.php';

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $username = $_POST['username'] ?? '';
        $password = $_POST['password'] ?? '';

        if (!empty($username) && !empty($password)) {
            $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

            // Insertar el nuevo administrador en la base de datos
            $sql = "INSERT INTO administradores (username, password) VALUES (?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ss", $username, $hashedPassword);

            if ($stmt->execute()) {
                echo "success";
            } else {
                echo "error";
            }

            $stmt->close();
        } else {
            echo "error";
        }

        $conn->close();
    }
?>
