<?php
    include 'db.php'; // Archivo de conexión a la base de datos

    header('Content-Type: application/json');

    $sql = "SELECT 
                id,
                fecha_prestamo,
                tipo_equipo,
                equipo,
                identificador_usuario,
                tipo_usuario,
                estado_devolucion,
                fecha_devolucion,
                hora_devolucion
            FROM historial_prestamos
            ORDER BY fecha_prestamo DESC, id DESC";

    $result = $conn->query($sql);

    $data = [];
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
    }

    echo json_encode($data);

    $conn->close();
?>
