<?php
    
    include 'db.php';

    // Verificar si se recibe la matrícula por GET
    if (isset($_GET['matricula'])) {
        $matricula = $_GET['matricula'];
        
        // Consulta para obtener la solicitud por matrícula
        $sql = "SELECT nombre, apellidos, matricula, semestre, carrera, motivo_uso, fecha, hora_inicio, hora_fin, tipo_equipo, equipo_disponible, ubicacion_uso 
                FROM solicitudes_e 
                WHERE matricula = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $matricula);
        $stmt->execute();
        $result = $stmt->get_result();

        // Si se encuentra el registro, devolverlo en formato JSON
        if ($result->num_rows > 0) {
            $data = $result->fetch_assoc();
            echo json_encode($data);
        } else {
            echo json_encode(null); // Enviar null si no se encuentran datos
        }

        $stmt->close();
    }

    // Verificar si se recibe el número de empleado por GET
    if (isset($_GET['teacherId'])) {
        $teacherId = $_GET['teacherId'];
        
        // Consulta para obtener la solicitud por número de empleado
        $sql = "SELECT nombre, apellidos, numero_empleado, correo, telefono, motivo_uso, fecha, hora_inicio, hora_fin, tipo_equipo, equipo_disponible, ubicacion_uso 
                FROM solicitudes_p 
                WHERE numero_empleado = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $teacherId);
        $stmt->execute();
        $result = $stmt->get_result();

        // Si se encuentra el registro, devolverlo en formato JSON
        if ($result->num_rows > 0) {
            $data = $result->fetch_assoc();
            echo json_encode($data);
        } else {
            echo json_encode(null); // Enviar null si no se encuentran datos
        }

        $stmt->close();
    }

?>