<?php
    include 'db.php';

    // Obtener el estado deseado de los parámetros GET, por defecto 'pendiente'
    $estado = isset($_GET['estado']) ? $conn->real_escape_string($_GET['estado']) : 'pendiente';

    // Realiza la consulta a la base de datos
    $sql = "SELECT 
        identificador,
        nombre_completo,
        carrera_departamento,
        motivo_uso,
        fecha,
        hora_inicio,
        hora_fin,
        tipo_equipo,
        estado,
        tipo_solicitante
    FROM vista_solicitudes_combinadas
    WHERE estado = '$estado'
    ORDER BY fecha, hora_inicio;";
    $result = $conn->query($sql);

    $data = [];
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
    }

    // Devuelve los datos como JSON
    header('Content-Type: application/json');
    echo json_encode($data);
?>
