<?php
    
    include 'db.php';

    // Verificar si se envió una solicitud de modificación
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['matricula'])) {
        $matricula = $_POST['matricula'];
        $nombre = $_POST['firstName'];
        $apellidos = $_POST['lastName']; // Los apellidos se manejan como un único campo
        $semestre = $_POST['semester'];
        $carrera = $_POST['career'];
        $fecha = $_POST['date'];
        $hora_inicio = $_POST['startTime'];
        $hora_fin = $_POST['endTime'];
        $tipo_equipo = $_POST['equipmentType'];
        $equipo_disponible = $_POST['equipment'];
        $motivo_uso = $_POST['useReason'];
        $ubicacion_uso = $_POST['useLocation'];

        // Consulta para actualizar los datos de la solicitud en la base de datos
        $sql = "UPDATE solicitudes_e SET nombre = ?, apellidos = ?, semestre = ?, carrera = ?, motivo_uso = ?, fecha = ?, hora_inicio = ?, hora_fin = ?, tipo_equipo = ?, equipo_disponible = ?, ubicacion_uso = ? WHERE matricula = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssssssssss", $nombre, $apellidos, $semestre, $carrera, $motivo_uso, $fecha, $hora_inicio, $hora_fin, $tipo_equipo, $equipo_disponible, $ubicacion_uso, $matricula);

        if ($stmt->execute()) {
            echo json_encode(["status" => "success", "message" => "La solicitud ha sido modificada con éxito."]);
        } else {
            echo json_encode(["status" => "error", "message" => "Error al modificar la solicitud."]);
        }

        $stmt->close();
        $conn->close();
        exit();
    }

    // Verificar si se envió una solicitud de modificación para profesores
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['teacherId'])) {
        $teacherId = $_POST['teacherId'];
        $nombre = $_POST['firstName'];
        $apellidos = $_POST['lastName']; // Los apellidos se manejan como un único campo
        $correo = $_POST['email'];
        $telefono = $_POST['phoneNumber'];
        $fecha = $_POST['date'];
        $hora_inicio = $_POST['startTime'];
        $hora_fin = $_POST['endTime'];
        $tipo_equipo = $_POST['equipmentType'];
        $equipo_disponible = $_POST['equipment'];
        $motivo_uso = $_POST['useReason'];
        $ubicacion_uso = $_POST['useLocation'];

        // Consulta para actualizar los datos de la solicitud en la base de datos
        $sql = "UPDATE solicitudes_p SET nombre = ?, apellidos = ?, correo = ?, telefono = ?, motivo_uso = ?, fecha = ?, hora_inicio = ?, hora_fin = ?, tipo_equipo = ?, equipo_disponible = ?, ubicacion_uso = ? WHERE numero_empleado = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssssssssss", $nombre, $apellidos, $correo, $telefono, $motivo_uso, $fecha, $hora_inicio, $hora_fin, $tipo_equipo, $equipo_disponible, $ubicacion_uso, $teacherId);

        if ($stmt->execute()) {
            echo json_encode(["status" => "success", "message" => "La solicitud del profesor ha sido modificada con éxito."]);
        } else {
            echo json_encode(["status" => "error", "message" => "Error al modificar la solicitud del profesor."]);
        }

        $stmt->close();
        $conn->close();
        exit();
    }

    $conn->close();
?>
